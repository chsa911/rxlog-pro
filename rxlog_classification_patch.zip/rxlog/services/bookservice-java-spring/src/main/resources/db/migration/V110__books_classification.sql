-- Adds optional book classification fields:
-- - is_fiction: TRUE=Fiction, FALSE=Non-Fiction, NULL=unspecified
-- - genre: broad category (e.g. "Krimi")
-- - sub_genre: more specific category (e.g. "Thriller")
-- - themes: free text / comma-separated topics (e.g. "Bergsteigen, Alpen")

ALTER TABLE books ADD COLUMN IF NOT EXISTS is_fiction boolean;
ALTER TABLE books ADD COLUMN IF NOT EXISTS genre text;
ALTER TABLE books ADD COLUMN IF NOT EXISTS sub_genre text;
ALTER TABLE books ADD COLUMN IF NOT EXISTS themes text;

CREATE INDEX IF NOT EXISTS idx_books_is_fiction ON books(is_fiction);
CREATE INDEX IF NOT EXISTS idx_books_genre ON books(genre);
CREATE INDEX IF NOT EXISTS idx_books_sub_genre ON books(sub_genre);
